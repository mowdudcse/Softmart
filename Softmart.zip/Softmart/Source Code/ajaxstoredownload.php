<?php
session_start();
error_reporting(0);
date_default_timezone_set('Asia/Kolkata'); 
include("dbconnection.php");
$dttim = date("Y-m-d H:i:s");
$sql = "DELETE software_download_record SET status='Previous' WHERE software_product_id='$_GET[software_product_id]' AND customer_id='$_SESSION[customerid]'";
mysqli_query($con,$sql);
$sql = "INSERT INTO software_download_record(software_product_id,customer_id,download_dt_tim,status) VALUES('$_GET[software_product_id]','$_SESSION[customerid]','$dttim','Active')";
mysqli_query($con,$sql);
echo mysqli_error($con);
?>