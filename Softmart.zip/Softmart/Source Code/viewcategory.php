<?php 
include("header.php");
include("dbconnection.php");
if(!isset($_SESSION['adminid']))
{
	echo "<script>window.location='adminloginpanel.php'; </script>";
}
if(isset($_GET['deleteid']))
{
	$sql = "DELETE FROM category WHERE category_id='$_GET[deleteid]'";
	if(!mysqli_query($con,$sql))
	{
		echo "<script>alert('Failed to delete record'); </script>";
	}
	else
	{
		if(mysqli_affected_rows($con)  >= 1)
		{
		echo "<script>alert('This record deleted successfully..'); </script>";
		}
	}
}
?>

	<!-- gray bg -->	
	<section class="container tm-home-section-1" id="more">
	
		<div class="section-margin-top">
			<div class="row">				
				<div class="tm-section-header">
					<div class="col-lg-3 col-md-3 col-sm-3"><hr></div>
					<div class="col-lg-6 col-md-6 col-sm-6"><h2 class="tm-section-title">View Category</h2></div>
					<div class="col-lg-3 col-md-3 col-sm-3"><hr></div>	
				</div>
			</div>
			<div class="row">
			



<?php
							$sql = "SELECT * FROM category  ";
							  $qsql = mysqli_query($con,$sql);
							if(mysqli_num_rows($qsql)  == 0)
									{
										echo "<center>There is no category to display!!</center>";
									}
									else
									{
										?>
<table ID="datatable" class="table table-striped table-bordered " >
<thead>
<tr>
							    <th><strong>Image</strong></th>
							    <th height="38"><strong>Category</strong></th>
							     <th><strong>Description</strong></th>
							    <th><strong>Status</strong></th>
                                   <th><strong>Action</strong></th>
  </tr>
  </thead>
  <tbody>
  <?php
 
  while($rs = mysqli_fetch_array($qsql))
  {
							  echo "
							  <tr>
							   <td>&nbsp;
								<img src='imgcategory/$rs[img]' width='100' height='100'>
								</td>
							    <td>&nbsp;$rs[category]</td>
							    <td>&nbsp;$rs[description]</td>
							    <td>&nbsp;$rs[status]</td>
								 <td>&nbsp; <a href='category.php?editid=$rs[category_id]' CLASS='btn btn-info'>Edit</a>  
								 <a href='viewcategory.php?deleteid=$rs[category_id]' onclick='return delconfirm()' CLASS='btn btn-danger'>Delete</a></td>
						      </tr>";
  }
  ?>
  </tbody>
</table>
						<?php
						 }
						?>


				
			</div>		
		</div>
	</section>		
	

  
<?php
include("footer.php");
?>
<script type="application/javascript">
function delconfirm()
{
	if(confirm("Are you sure you want to delete this record?") == true)
	{
		return true;
	}
	else
	{
		return false;
	}
}
</script>