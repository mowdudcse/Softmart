	<footer class="tm-black-bg">
		<div class="container">
			<div class="row">
				<p class="tm-copyright-text">Copyright &copy; <?php echo date("Y"); ?> SoftMart 
<?php				
if(!isset($_SESSION['customerid']) && !isset($_SESSION['adminid']) )
{
?>
				| <a href="adminlogin.php">Admin Login</a>
<?php
}
?>
				</p>
			</div>
		</div>		
	</footer>
	<script type="text/javascript" src="js/jquery-1.11.2.min.js"></script>      		<!-- jQuery -->
  	<script type="text/javascript" src="js/moment.js"></script>							<!-- moment.js -->
	<script type="text/javascript" src="js/bootstrap.min.js"></script>					<!-- bootstrap js -->
  <script src="js/jquery.dataTables.min.js"></script>
  
<script>
$(document).ready( function () {
    $('#datatable').DataTable();
	
} );
</script>
 </body>
 </html>