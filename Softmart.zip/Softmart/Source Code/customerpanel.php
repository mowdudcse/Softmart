<?php
include("header.php");
if(!isset($_SESSION['customerid']))
{
	echo "<script>window.location='adminloginpanel.php'; </script>";
}
?>
  <main id="main">

    <!-- ======= Contact Section ======= -->
	<section class="container tm-home-section-1" id="more">
	
		<div class="section-margin-top">
			<div class="row">				
				<div class="tm-section-header">
					<div class="col-lg-3 col-md-3 col-sm-3"><hr></div>
					<div class="col-lg-6 col-md-6 col-sm-6"><h2 class="tm-section-title">CUSTOMER PANEL</h2></div>
					<div class="col-lg-3 col-md-3 col-sm-3"><hr></div>	
				</div>
			</div>
			<div class="row">
			
			
			
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xxs-12">
					<div class="tm-home-box-2">				
						<img src="img/custprofile.png" alt="image" class="img-responsive" style="height: 200px;width: 100%;">
						<h3>Customer Profile</h3>
						<div class="tm-home-box-2-container">
							<a href="custprofile.php" class="tm-home-box-2-link"><i class="fa fa-edit tm-home-box-2-icon border-left"></i>UPDATE PROFILE</a>
						</div>
					</div>
				</div>
				
			
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xxs-12">
					<div class="tm-home-box-2">				
						<img src="img/category.png" alt="image" class="img-responsive" style="height: 200px;">
						<h3>Change Password</h3>
						<div class="tm-home-box-2-container">
							<a href="cstchangepassword.php" class="tm-home-box-2-link"><i class="fa fa-key tm-home-box-2-icon border-left"></i>CHANGE PASSWORD</a>
						</div>
					</div>
				</div>
				
				
				
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xxs-12">
					<div class="tm-home-box-2">				
						<img src="img/soft.jpg" alt="image" class="img-responsive" style="height: 200px;">
						<h3>My Downloads</h3>
						<div class="tm-home-box-2-container">
							<a href="viewdownloads.php" class="tm-home-box-2-link"><i class="fa fa-download tm-home-box-2-icon border-left"></i>VIEW DOWNLAODS</a>
						</div>
					</div>
				</div>
				
				
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xxs-12">
					<div class="tm-home-box-2">				
						<img src="images/feedback.jpg" alt="image" class="img-responsive" style="height: 200px;">
						<h3>My Feedbacks & Comments</h3>
						<div class="tm-home-box-2-container">
							<a href="viewfeedbacks.php" class="tm-home-box-2-link"><i class="fa fa-book tm-home-box-2-icon border-left"></i>My Feedbacks & Comments</a>
						</div>
					</div>
				</div>
				
				
				
				
			</div>		
		</div>
	</section>	


  </main><!-- End #main -->
  
<?php
include("footer.php");
?>
<script>
$(document).ready( function () {
    $('#datatable').DataTable();
} );
</script>