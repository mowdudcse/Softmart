<?php 
include("header.php");
include("dbconnection.php");
if(!isset($_SESSION['customerid']))
{
	echo "<script>window.location='customerloginpanel.php'; </script>";
}

?>

	<!-- white bg -->
	<section class="tm-white-bg section-padding-bottom">
		<div class="container">

			<div class="row">
				<div class="tm-section-header section-margin-top" style="margin-bottom: 25px;margin-top: 25px;">
					<div class="col-lg-4 col-md-3 col-sm-3"><hr></div>
					<div class="col-lg-4 col-md-6 col-sm-6"><h2 class="tm-section-title">FEEDBACK & REVIEWS</h2></div>
					<div class="col-lg-4 col-md-3 col-sm-3"><hr></div>	
				</div>				
			</div>
			

<?php
$sqlcommentcount = "SELECT count(*) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE comment.customer_id='$_SESSION[customerid]'";
$qsqlcmmentcount = mysqli_query($con,$sqlcommentcount);
$rscomentcount = mysqli_fetch_array($qsqlcmmentcount);
if($rscomentcount[0] == 0)
{
?>
	<div class="row"> 
		<div class="col-md-12">
			No Comments published..
		</div>
	</div>
<?php
}
else
{
?>			
			<div class="row">
			
				<!-- Testimonial -->
				<div>
				
			

    <div class="container">
    			
		<div class="row">
			<div class="col-sm-6">
				<div class="rating-block">
					<h4>Average user rating</h4>
					<h1 class="bold padding-bottom-7">


					<small> 
<?php					

$sqlcommenttotal = "SELECT sum(ratings) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE comment.customer_id='$_SESSION[customerid]'";
$qsqlcmmenttotal = mysqli_query($con,$sqlcommenttotal);
$rscomenttotal = mysqli_fetch_array($qsqlcmmenttotal);
echo  number_format($rscomenttotal[0] / $rscomentcount[0],1);
$tot =  round($rscomenttotal[0] / $rscomentcount[0]);
?>
					/ 5</small></h1>


								<button type="button" class="<?php
	  if($tot >= 1 )
	  {
		  echo  " btn btn-warning btn-sm ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-sm ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
								<button type="button" class="<?php
	  if($tot >= 2 )
	  {
		  echo  " btn btn-warning btn-sm ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-sm ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
								<button type="button" class="<?php
	  if($tot >= 3 )
	  {
		  echo  " btn btn-warning btn-sm ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-sm ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
								<button type="button" class="<?php
	  if($tot >= 4 )
	  {
		  echo  " btn btn-warning btn-sm ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-sm ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
								<button type="button" class="<?php
	  if($tot >= 5 )
	  {
		  echo  " btn btn-warning btn-sm ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-sm ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
<br>
<b>Total <?php echo $rscomentcount[0]; ?> Comments...</b>

				</div>
			</div>
			<div class="col-sm-3">
				<h4>Rating breakdown</h4>
				<div class="pull-left">
					<div class="pull-left" style="width:35px; line-height:1;">
						<div style="height:9px; margin:5px 0;">5 <span class="glyphicon glyphicon-star"></span></div>
					</div>
					<div class="pull-left" style="width:180px;">
						<div class="progress" style="height:9px; margin:8px 0;">
						  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="5" aria-valuemin="0" aria-valuemax="5" style="width: 1000%">
							<span class="sr-only">80% Complete (danger)</span>
						  </div>
						</div>
					</div>
					<div class="pull-right" style="margin-left:10px;">
<?php
$sqlcommentcount = "SELECT count(*) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE comment.customer_id='$_SESSION[customerid]' AND comment.ratings='5'";
$qsqlcmmentcount = mysqli_query($con,$sqlcommentcount);
$rscomentcount = mysqli_fetch_array($qsqlcmmentcount);
echo $rscomentcount[0];
?>
					</div>
				</div>
				<div class="pull-left">
					<div class="pull-left" style="width:35px; line-height:1;">
						<div style="height:9px; margin:5px 0;">4 <span class="glyphicon glyphicon-star"></span></div>
					</div>
					<div class="pull-left" style="width:180px;">
						<div class="progress" style="height:9px; margin:8px 0;">
						  <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="4" aria-valuemin="0" aria-valuemax="5" style="width: 80%">
							<span class="sr-only">80% Complete (danger)</span>
						  </div>
						</div>
					</div>
					<div class="pull-right" style="margin-left:10px;">
<?php
$sqlcommentcount = "SELECT count(*) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE comment.customer_id='$_SESSION[customerid]' AND comment.ratings='4'";
$qsqlcmmentcount = mysqli_query($con,$sqlcommentcount);
$rscomentcount = mysqli_fetch_array($qsqlcmmentcount);
echo $rscomentcount[0];
?>
					</div>
				</div>
				<div class="pull-left">
					<div class="pull-left" style="width:35px; line-height:1;">
						<div style="height:9px; margin:5px 0;">3 <span class="glyphicon glyphicon-star"></span></div>
					</div>
					<div class="pull-left" style="width:180px;">
						<div class="progress" style="height:9px; margin:8px 0;">
						  <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="3" aria-valuemin="0" aria-valuemax="5" style="width: 60%">
							<span class="sr-only">80% Complete (danger)</span>
						  </div>
						</div>
					</div>
					<div class="pull-right" style="margin-left:10px;">
<?php
$sqlcommentcount = "SELECT count(*) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE comment.customer_id='$_SESSION[customerid]' AND comment.ratings='3'";
$qsqlcmmentcount = mysqli_query($con,$sqlcommentcount);
$rscomentcount = mysqli_fetch_array($qsqlcmmentcount);
echo $rscomentcount[0];
?>
					</div>
				</div>
				<div class="pull-left">
					<div class="pull-left" style="width:35px; line-height:1;">
						<div style="height:9px; margin:5px 0;">2 <span class="glyphicon glyphicon-star"></span></div>
					</div>
					<div class="pull-left" style="width:180px;">
						<div class="progress" style="height:9px; margin:8px 0;">
						  <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="2" aria-valuemin="0" aria-valuemax="5" style="width: 40%">
							<span class="sr-only">80% Complete (danger)</span>
						  </div>
						</div>
					</div>
					<div class="pull-right" style="margin-left:10px;">
<?php
$sqlcommentcount = "SELECT count(*) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE comment.customer_id='$_SESSION[customerid]' AND comment.ratings='2'";
$qsqlcmmentcount = mysqli_query($con,$sqlcommentcount);
$rscomentcount = mysqli_fetch_array($qsqlcmmentcount);
echo $rscomentcount[0];
?>
					</div>
				</div>
				<div class="pull-left">
					<div class="pull-left" style="width:35px; line-height:1;">
						<div style="height:9px; margin:5px 0;">1 <span class="glyphicon glyphicon-star"></span></div>
					</div>
					<div class="pull-left" style="width:180px;">
						<div class="progress" style="height:9px; margin:8px 0;">
						  <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="1" aria-valuemin="0" aria-valuemax="5" style="width: 20%">
							<span class="sr-only">80% Complete (danger)</span>
						  </div>
						</div>
					</div>
					<div class="pull-right" style="margin-left:10px;">
<?php
$sqlcommentcount = "SELECT count(*) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE comment.customer_id='$_SESSION[customerid]' AND comment.ratings='1'";
$qsqlcmmentcount = mysqli_query($con,$sqlcommentcount);
$rscomentcount = mysqli_fetch_array($qsqlcmmentcount);
echo $rscomentcount[0];
?>
					</div>
				</div>
				</div>
			</div>			
		</div>			
		
		<div class="row">
			<div class="col-sm-12">
				<hr/>
				<div class="review-block">
				
<?php
$sqlcomment1 = "SELECT * FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE comment.customer_id='$_SESSION[customerid]' ORDER BY comment.comment_date DESC";
$qsqlcmment = mysqli_query($con,$sqlcomment1);
while($rscoment = mysqli_fetch_array($qsqlcmment))
{
	if(file_exists("imgcustomer/".$rscoment['profile_img']))
	{
		$img = "imgcustomer/".$rscoment['profile_img'];
	}
	else
	{
		$img = "images/noimage.png";
	}
?>				
					<div class="row">
						<div class="col-sm-3">
							<img src="<?php echo $img; ?>" class="img-rounded" style="width: 120px;height: 125px;" align="left" >
							<div class="review-block-name"><b style='color: blue;margin-left: 10px;'><?php echo $rscoment['customer_name']; ?></b></div>
							<div class="review-block-date"><b style='margin-left: 10px;'><?php echo date("F d, Y",strtotime($rscoment['comment_date'])); ?></b><br/><?php /* <b style='margin-left: 10px;'>1 day ago</b>*/ ?></div>
						</div>
						<div class="col-sm-9">
							<div class="review-block-rate">
								<button type="button" class="<?php
	  if($rscoment['ratings'] >= 1 )
	  {
		  echo  " btn btn-warning btn-xs ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-xs ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
								<button type="button" class="<?php
	  if($rscoment['ratings'] >= 2 )
	  {
		  echo  " btn btn-warning btn-xs ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-xs ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
								<button type="button" class="<?php
	  if($rscoment['ratings'] >= 3 )
	  {
		  echo  " btn btn-warning btn-xs ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-xs ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
								<button type="button" class="<?php
	  if($rscoment['ratings'] >= 4 )
	  {
		  echo  " btn btn-warning btn-xs ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-xs ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
								<button type="button" class="<?php
	  if($rscoment['ratings'] >= 5 )
	  {
		  echo  " btn btn-warning btn-xs ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-xs ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
							</div>
							<?php /*<div class="review-block-title">this was nice in buy</div>*/ ?>
							<div class="review-block-description"><?php echo $rscoment['comment_note']; ?></div>
						</div>
					</div>
					<hr/>
<?php
}
?>
				
				</div>
			</div>
		</div>
		
    </div> <!-- /container -->


			
			
				</div>							
			
<?php
}
?>
			</div>			
		</div>
	</section>

  
<?php
include("footer.php");
?>