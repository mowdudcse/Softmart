<?php
include("header.php");
include("dbconnection.php");
if(!isset($_SESSION['adminid']))
{
	echo "<script>window.location='adminloginpanel.php'; </script>";
}
?>
  <main id="main">

    <!-- ======= Contact Section ======= -->
	<section class="container tm-home-section-1" id="more">
	
		<div class="section-margin-top">
			<div class="row">				
				<div class="tm-section-header">
					<div class="col-lg-3 col-md-3 col-sm-3"><hr></div>
					<div class="col-lg-6 col-md-6 col-sm-6"><h2 class="tm-section-title">ADMIN PANEL</h2></div>
					<div class="col-lg-3 col-md-3 col-sm-3"><hr></div>	
				</div>
			</div>
			<div class="row">
			
			
			
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xxs-12">
					<div class="tm-home-box-2">				
						<img src="img/category.png" alt="image" class="img-responsive" style="height: 200px;">
						<h3>Category Records</h3>
						<div class="tm-home-box-2-container">
							<a href="category.php" class="tm-home-box-2-link" style="width: 100px;"><i class="fa fa-plus tm-home-box-2-icon border-left"></i>ADD</a>
							<a href="viewcategory.php" class="tm-home-box-2-link" style="width: 100px;"><i class="fa fa-eye tm-home-box-2-icon border-left"></i>VIEW</a>
						</div>
					</div>
				</div>
				
				
				
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xxs-12">
					<div class="tm-home-box-2">				
						<img src="img/soft.jpg" alt="image" class="img-responsive" style="height: 200px;">
						<h3>Software/App Records</h3>
						<div class="tm-home-box-2-container">
							<a href="software.php" class="tm-home-box-2-link" style="width: 100px;"><i class="fa fa-plus tm-home-box-2-icon border-left"></i>ADD</a>
							<a href="viewsoftware.php" class="tm-home-box-2-link" style="width: 100px;"><i class="fa fa-eye tm-home-box-2-icon border-left"></i>VIEW</a>
						</div>
					</div>
				</div>
				
							
				
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xxs-12">
					<div class="tm-home-box-2">				
						<img src="images/downloads.png" alt="image" class="img-responsive" style="height: 200px;width:100%;">
						<h3>View Customer Downloads</h3>
						<div class="tm-home-box-2-container">
							<a href="viewdownloads.php" class="tm-home-box-2-link"><i class="fa fa-download tm-home-box-2-icon border-left"></i>VIEW DOWNLAODS</a>
						</div>
					</div>
				</div>
				
								
				
				<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xxs-12">
					<div class="tm-home-box-2">				
						<img src="images/customers.jpg" alt="image" class="img-responsive" style="height: 200px;width:100%;">
						<h3>View Customers</h3>
						<div class="tm-home-box-2-container">
							<a href="viewcustomers.php" class="tm-home-box-2-link"><i class="fa fa-download tm-home-box-2-icon border-left"></i>VIEW Customer</a>
						</div>
					</div>
				</div>
				
				
			</div>		
		</div>
	</section>	


  </main><!-- End #main -->
  
<?php
include("footer.php");
?>
<script>
$(document).ready( function () {
    $('#datatable').DataTable();
} );
</script>