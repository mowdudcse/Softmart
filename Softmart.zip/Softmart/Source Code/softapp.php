<?php
include("header.php");
?>
	<!-- white bg -->
	<section class="tm-white-bg section-padding-bottom">
		<div class="container">
		
<div class="row">

	<div class="col-md-2">
<br>
<h3><b data-filter="*" class="filter-active">Category</b></h3><hr>

<?php
$sqlcategory = "SELECT * FROM category WHERE status='Active'";
$qsqlcategory = mysqli_query($con,$sqlcategory);
while($rseditcategory = mysqli_fetch_array($qsqlcategory))
{
	echo "<a href='softapp.php?category_id=$rseditcategory[category_id]' class='btn btn-info btn-block' >$rseditcategory[category]</a>";
}
?>
	</div>
	<div class="col-md-10">
			
				<div class="row">				
					<div class="">	<br>				
					<h3>
<?php
if(isset($_GET['category_id']))
{
	$sqlviewcategory = "SELECT * FROM category WHERE category_id ='" . $_GET['category_id'] ."'";
	$qsqlviewcategory = mysqli_query($con,$sqlviewcategory);
	$rsviewcategory = mysqli_fetch_array($qsqlviewcategory);
?>
<center><b data-filter="*" class="filter-active"><?php echo $rsviewcategory['category']; ?></b></centeR>
<?php
}
else
{
?>
<center><b data-filter="*" class="filter-active">All Software Store</b></center>
<?php
}
?>					
					</h3><hr>
					</div>				
				</div>
				
				
<?php
	$row=0; $col=0;
	$sql = "SELECT * FROM software_product WHERE status='Active'";
	if(isset($_GET['category_id']))
	{
		$sql = $sql . " AND category_id='$_GET[category_id]'";
	}
	$sql = $sql . " ORDER BY software_product_id DESC";
	$qsql = mysqli_query($con,$sql);
	while($rs = mysqli_fetch_array($qsql))
	{
		$sqlcategory = "SELECT * FROM category WHERE category_id='$rs[category_id]'";
		$qsqlcategory = mysqli_query($con,$sqlcategory);
		$rseditcategory = mysqli_fetch_array($qsqlcategory);
?>	
				<?php
				if($col==0)
				{
				?>
				<div class="row">
				<?php
				}
				?>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xxs-12">
	<div class="tm-tours-box-2">						
		<img src="imgsoftwareproduct/<?php echo $rs['product_img1']; ?>" alt="image" class="img-responsive" style="width: 214px; height: 146px;">
		<div class="tm-tours-box-2-info">
			<h3 class="margin-bottom-15"><b style='color: green;'><?php echo $rs['product_name']; ?> <?php echo $col; ?></b></h3>
			<p><b style='color: blue;'><?php echo $rseditcategory['category']; ?></b></p>	
			<img src="img/rating.png" alt="image" class="margin-bottom-5">
			<p><b>Type: <?php echo $rs['software_type']; ?></b></p>	
		</div>						
		<a href="softappdetail.php?software_product_id=<?php echo $rs[0]; ?>" class="tm-tours-box-2-link">View more</a>
	</div>
</div>
				<?php
				if($col==3)
				{
				?>
				</div>
				<br>
				<?php
				$col=0;
				}
				else
				{
					$col = $col +1;
				}
				?>
<?php
	}
?>
				
<?php
/*				
				<div class="row">
					<div class="col-lg-12">
						<p class="home-description">Lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris.
						Morbi accumsaipsu m velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat.
						</p>					
					</div>
				</div>	
*/
?>
			
	</div>		

</div>
		</div>
	</section>

<?php
include("footer.php");
?>