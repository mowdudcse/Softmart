<?php
session_start();
error_reporting(0);
include("dbconnection.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>SoftMart - Online Software /Apps Store</title>
  <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,400italic,600,700' rel='stylesheet' type='text/css'>
  <link href="css/font-awesome.min.css" rel="stylesheet">
  <link href="css/bootstrap.min.css" rel="stylesheet">
  <link href="css/bootstrap-datetimepicker.min.css" rel="stylesheet">  
  <link href="css/flexslider.css" rel="stylesheet">
  <link href="css/templatemo-style.css" rel="stylesheet">
  <link href="css/jquery.dataTables.min.css" rel="stylesheet">
  
  </head>
  <body class="tm-gray-bg">
  
  
  	<!-- Header -->
  	<div class="tm-header">
  		<div class="container">
  			<div class="row">
  				<div class="col-lg-6 col-md-4 col-sm-3 tm-site-name-container">
  					<a href="index.php" class="tm-site-name">SoftMart</a>	
  				</div>
	  			<div class="col-lg-6 col-md-8 col-sm-9">
	  				<div class="mobile-menu-icon">
		              <i class="fa fa-bars"></i>
		            </div>
	  				<nav class="tm-nav">
						<ul>
							<li><a href="index.php" 
							<?php
							if(basename($_SERVER['PHP_SELF']) == "index.php")
							{
								echo " class='active' ";
							}
							?>
							>Home</a></li>
							<li><a href="softapp.php" 
							<?php
							if(basename($_SERVER['PHP_SELF']) == "softapp.php")
							{
								echo " class='active' ";
							}
							?>
							>Soft Store</a></li>
							
<?php
if(isset($_SESSION['customerid']))
{
?>
							
							<li><a href="customerpanel.php" 
							<?php
							if(basename($_SERVER['PHP_SELF']) == "customerpanel.php")
							{
								echo " class='active' ";
							}
							?>
							>My Account</a></li>
							


							<li><a href="logout.php" 
							<?php
							if(basename($_SERVER['PHP_SELF']) == "logout.php")
							{
								echo " class='active' ";
							}
							?>
							>Logout</a></li>
<?php
}
else if(isset($_SESSION['adminid']))
{
?>
							
							<li><a href="adminpanel.php" 
							<?php
							if(basename($_SERVER['PHP_SELF']) == "adminpanel.php")
							{
								echo " class='active' ";
							}
							?>
							>Dashboard</a></li>
							


							<li><a href="logout.php" 
							<?php
							if(basename($_SERVER['PHP_SELF']) == "logout.php")
							{
								echo " class='active' ";
							}
							?>
							>Logout</a></li>
<?php
}
else	
{
?>							
							
							<li><a href="customerReg.php" 
							<?php
							if(basename($_SERVER['PHP_SELF']) == "customerReg.php")
							{
								echo " class='active' ";
							}
							?>
							>Register</a></li>
							


							<li><a href="customerloginpanel.php" 
							<?php
							if(basename($_SERVER['PHP_SELF']) == "customerloginpanel.php")
							{
								echo " class='active' ";
							}
							?>
							>Login</a></li>
<?php
}
?>

							
						</ul>
					</nav>		
	  			</div>				
  			</div>
  		</div>	  	
  	</div>
	