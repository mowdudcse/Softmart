<?php
include("header.php");
if(isset($_SESSION["adminid"]))
{
	echo "<script>window.location='adminpanel.php';</script>";
}
if($_SESSION['randnumber']  == $_POST['randnumber'])
{
	if(isset($_POST['submit']))
	{
		$sql = "SELECT * FROM admin WHERE login_id='$_POST[emailid]' AND password='$_POST[password]' AND status='Active' ";
		$qsql = mysqli_query($con,$sql);
		if(mysqli_num_rows($qsql) == 1)
		{
			$rslogin = mysqli_fetch_array($qsql);
			$_SESSION['adminid'] = $rslogin['admin_id'];
			echo "<script>window.location='adminpanel.php';</script>";
		}
		else
		{
			echo "<script>alert('Login ID and password not valid..');</script>";	
		}
	}
}
$randnumber = rand();
$_SESSION['randnumber'] = $randnumber;
?>

	<!-- gray bg -->	
	<section class="container tm-home-section-1" id="more">
	
		<div class="section-margin-top">
			<div class="row">				
				<div class="tm-section-header">
					<div class="col-lg-3 col-md-3 col-sm-3"><hr></div>
					<div class="col-lg-6 col-md-6 col-sm-6"><h2 class="tm-section-title">Admin Login</h2></div>
					<div class="col-lg-3 col-md-3 col-sm-3"><hr></div>	
				</div>
			</div>
			<div class="row">
			
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
						<div class="tm-tours-box-1-info">

<div class="col-md-4 d-flex align-items-stretch mt-4 mt-lg-0">
                <div class="icon-box" data-aos="zoom-in" data-aos-delay="200" style="width: 100%;">
                  <img src="images/women.png" style="width: 100%;">
                </div>
              </div>
              <div class="col-md-8 d-flex align-items-stretch">
                <div class="icon-box" data-aos="zoom-in" data-aos-delay="100" style="width: 100%;text-align: left;">
<form method="post" action="" name="frmadminlogin" onSubmit="return validateadminlogin()">
                  <h4>Login Panel</h4>
<input type="hidden" name="randnumber" value="<?php echo $randnumber; ?>" >

<div class="form-group">
    <label for="exampleInputEmail1">Login ID</label>
    <input type="text" class="form-control" id="emailid" name="emailid" aria-describedby="emailHelp" placeholder="Enter Login ID">
</div>
<div class="form-group">
	<label for="exampleInputPassword1">Password</label>
	<input type="password" class="form-control"  placeholder="Password"  id="password" name="password">
</div>

<button type="submit" name="submit" id="submit" class="btn btn-info btn-lg btn-block" >Click here to Login</button>

</form>
                </div>
              </div>



						</div>				
				</div>
				
			</div>		
		</div>
	</section>		
	

<?php
include("footer.php");
?>