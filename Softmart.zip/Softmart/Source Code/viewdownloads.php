<?php 
include("header.php");
include("dbconnection.php");
if(!isset($_SESSION['customerid']) && !isset($_SESSION['adminid']))
{
	echo "<script>window.location='customerloginpanel.php'; </script>";
}
if(isset($_GET['deleteid']))
{
	$sql = "DELETE FROM category WHERE category_id='$_GET[deleteid]'";
	if(!mysqli_query($con,$sql))
	{
		echo "<script>alert('Failed to delete record'); </script>";
	}
	else
	{
		if(mysqli_affected_rows($con)  >= 1)
		{
		echo "<script>alert('This record deleted successfully..'); </script>";
		}
	}
}
?>

	<!-- gray bg -->	
	<section class="container tm-home-section-1" id="more">
	
		<div class="section-margin-top">
			<div class="row">				
				<div class="tm-section-header">
					<div class="col-lg-3 col-md-3 col-sm-3"><hr></div>
					<div class="col-lg-6 col-md-6 col-sm-6"><h2 class="tm-section-title">View Downloads</h2></div>
					<div class="col-lg-3 col-md-3 col-sm-3"><hr></div>	
				</div>
			</div>
			<div class="row">
			



<?php
							$sql = "SELECT software_download_record.*,customer.customer_name, software_product.product_name,software_product.product_img1 FROM software_download_record left join customer on customer.customer_id=software_download_record.customer_id LEFT JOIN software_product ON software_product.software_product_id=software_download_record.software_product_id WHERE software_download_record.software_download_record_id!='0' ";
							if(isset($_SESSION['customerid']))
							{
								$sql = $sql . "  AND software_download_record.customer_id='$_SESSION[customerid]' ";
							}
								$sql = $sql . " AND software_download_record.status='Active'";
							  $qsql = mysqli_query($con,$sql);
							if(mysqli_num_rows($qsql)  == 0)
									{
										echo "<center>There is no category to display!!</center>";
									}
									else
									{
										?>
<table ID="datatable" class="table table-striped table-bordered " >
<thead>
<tr>
							    <th><strong>Software Icon</strong></th>
							    <th height="38"><strong>Software Name</strong></th>
							     <th><strong>Customer</strong></th>
							     <th><strong>Download Date</strong></th>
  </tr>
  </thead>
  <tbody>
  <?php
 
  while($rs = mysqli_fetch_array($qsql))
  {
							  echo "
							  <tr>
							   <td>&nbsp;
								<img src='imgsoftwareproduct/$rs[product_img1]' width='100' height='100'>
								</td>
							    <td>&nbsp;$rs[product_name]</td>
							    <td>&nbsp;$rs[customer_name]</td>
							    <td>&nbsp;" . date("d-m-Y h:i:A",strtotime($rs['download_dt_tim'])) . "</td>
						      </tr>";
  }
  ?>
  </tbody>
</table>
						<?php
						 }
						?>


				
			</div>		
		</div>
	</section>		
	

  
<?php
include("footer.php");
?>
<script type="application/javascript">
function delconfirm()
{
	if(confirm("Are you sure you want to delete this record?") == true)
	{
		return true;
	}
	else
	{
		return false;
	}
}
</script>