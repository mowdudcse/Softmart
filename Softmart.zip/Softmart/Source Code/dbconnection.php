<?php
//error_reporting(0);
// Create connection
$con=mysqli_connect("localhost","root","","softmart");
echo mysqli_connect_error();
?>