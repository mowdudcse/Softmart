<?php
include("header.php");
?>
<style>
.checked {
  color: orange;
}
</style>
	<!-- white bg -->
	<section class="tm-white-bg section-padding-bottom">
		<div class="container">
		
<div class="row">

	<div class="col-md-2">
<br>
<h3><b data-filter="*" class="filter-active">Category</b></h3><hr>

<?php
$sqlcategory = "SELECT * FROM category WHERE status='Active'";
$qsqlcategory = mysqli_query($con,$sqlcategory);
while($rseditcategory = mysqli_fetch_array($qsqlcategory))
{
	echo "<a href='softapp.php?category_id=$rseditcategory[category_id]' class='btn btn-info btn-block' >$rseditcategory[category]</a>";
}
?>
	</div>
	<div class="col-md-10">
			
				<div class="row">				
					<div class="">	<br>				
					<h3>
<?php
if(isset($_GET['category_id']))
{
?>
<center><b data-filter="*" class="filter-active"><?php echo $_GET['category']; ?></b></centeR>
<?php
}
else
{
?>
<center><b data-filter="*" class="filter-active">Latest Softwares</b></center>
<?php
}
?>					
					</h3><hr>
					</div>				
				</div>
				
				
<?php
	$row=0; $col=0;
	$sql = "SELECT * FROM software_product WHERE status='Active'";
	$sql = $sql . " ORDER BY software_product_id DESC limit 4";
	$qsql = mysqli_query($con,$sql);
	while($rs = mysqli_fetch_array($qsql))
	{
		$sqlcategory = "SELECT * FROM category WHERE category_id='$rs[category_id]'";
		$qsqlcategory = mysqli_query($con,$sqlcategory);
		$rseditcategory = mysqli_fetch_array($qsqlcategory);
?>	
				<?php
				if($col==0)
				{
				?>
				<div class="row">
				<?php
				}
				?>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xxs-12">
	<div class="tm-tours-box-2">						
		<img src="imgsoftwareproduct/<?php echo $rs['product_img1']; ?>" alt="image" class="img-responsive" style="width: 214px; height: 146px;">
		<div class="tm-tours-box-2-info">
			<h3 class="margin-bottom-15"><b style='color: green;'><?php echo $rs['product_name']; ?> </b></h3>
			<p><b style='color: blue;'><?php echo $rseditcategory['category']; ?></b></p>	
			<?php
//#####################################
$sqlcommentcount = "SELECT count(*) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE software_product_id='$rs[software_product_id]'";
$qsqlcmmentcount = mysqli_query($con,$sqlcommentcount);
$rscomentcount = mysqli_fetch_array($qsqlcmmentcount);
if (is_null($rscomentcount[0])) {
	$commentcount = 0;
} else {
	$commentcount = $rscomentcount[0];
}
//#####################################
$sqlcommenttotal = "SELECT sum(ratings) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE software_product_id='$rs[software_product_id]'";
$qsqlcmmenttotal = mysqli_query($con,$sqlcommenttotal);
$rscomenttotal = mysqli_fetch_array($qsqlcmmenttotal);
if (is_null($rscomenttotal[0])) {
	$comenttotal = 0;
} else {
	$comenttotal = $rscomenttotal[0];
}
//#####################################
if($comenttotal == 0)
{
	$tot = 0;
}
else
{
	$tot =  round($comenttotal / $commentcount);
}
?>
<span class="fa fa-star
<?php
if($tot >=1)
{
	echo "checked";
}
?>"></span>
<span class="fa fa-star 
<?php
if($tot >=2)
{
	echo "checked";
}
?>"></span>
<span class="fa fa-star 
<?php
if($tot >=3)
{
	echo "checked";
}
?>"></span>
<span class="fa fa-star
<?php
if($tot >=4)
{
	echo "checked";
}
?>"></span>
<span class="fa fa-star
<?php
if($tot >=5)
{
	echo "checked";
}
?>"></span>
			<p><b>Type: <?php echo $rs['software_type']; ?></b></p>	
		</div>						
		<a href="softappdetail.php?software_product_id=<?php echo $rs[0]; ?>" class="tm-tours-box-2-link">View more</a>
	</div>
</div>
				<?php
				if($col==3)
				{
				?>
				</div>
				<br>
				<?php
				$col=0;
				}
				else
				{
					$col = $col +1;
				}
				?>
<?php
	}
?>
				
<?php
/*				
				<div class="row">
					<div class="col-lg-12">
						<p class="home-description">Lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris.
						Morbi accumsaipsu m velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat.
						</p>					
					</div>
				</div>	
*/
?>
			
	</div>		

</div>
		</div>
	</section>
<hr>

<?php
$sqlcategorya = "SELECT * FROM category WHERE status='Active'";
$qsqlcategorya = mysqli_query($con,$sqlcategorya);
while($rseditcategorya = mysqli_fetch_array($qsqlcategorya))
{
	$sqlsoftware_product = "SELECT * FROM software_product WHERE status='Active'";
	$sqlsoftware_product = $sqlsoftware_product . " AND category_id='$rseditcategorya[category_id]'";
	$sqlsoftware_product = $sqlsoftware_product . " ORDER BY software_product_id DESC LIMIT 4";
	$qsqlsoftware_product = mysqli_query($con,$sqlsoftware_product);
	if(mysqli_num_rows($qsqlsoftware_product) >= 1)
	{
	echo "<a href='softapp.php?category_id=$rseditcategorya[category_id]' class='btn btn-info btn-block' >$rseditcategorya[category]</a>";
?>
	<!-- white bg -->
	<section class="tm-white-bg section-padding-bottom">
		<div class="container">
		
				<div class="row">				
					<div class="">	<br>				
					<h3>
<?php
if(isset($_GET['category_id']))
{
?>
<center><b data-filter="*" class="filter-active"><?php echo $rseditcategorya['category']; ?></b></centeR>
<?php
}
?>					
					</h3>
					</div>				
				</div>
				
				
<?php
	$row=0; $col=0;
	$sql = "SELECT * FROM software_product WHERE status='Active'";
	$sql = $sql . " AND category_id='$rseditcategorya[category_id]'";
	$sql = $sql . " ORDER BY software_product_id DESC LIMIT 4";
	$qsql = mysqli_query($con,$sql);
	while($rs = mysqli_fetch_array($qsql))
	{
		$sqlcategory = "SELECT * FROM category WHERE category_id='$rs[category_id]'";
		$qsqlcategory = mysqli_query($con,$sqlcategory);
		$rseditcategory = mysqli_fetch_array($qsqlcategory);
?>	
				<?php
				if($col==0)
				{
				?>
				<div class="row">
				<?php
				}
				?>
<div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 col-xxs-12">
	<div class="tm-tours-box-2">						
		<img src="imgsoftwareproduct/<?php echo $rs['product_img1']; ?>" alt="image" class="img-responsive" style="width: 100%; height: 146px;">
		<div class="tm-tours-box-2-info">
			<h3 class="margin-bottom-15"><b style='color: green;'><?php echo $rs['product_name']; ?></b></h3>
			<p><b style='color: blue;'><?php echo $rseditcategory['category']; ?></b></p>	
			<p><b>Type: <?php echo $rs['software_type']; ?></b></p>	


<?php
//#####################################
$sqlcommentcount = "SELECT count(*) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE software_product_id='$rs[software_product_id]'";
$qsqlcmmentcount = mysqli_query($con,$sqlcommentcount);
$rscomentcount = mysqli_fetch_array($qsqlcmmentcount);
if (is_null($rscomentcount[0])) {
	$commentcount = 0;
} else {
	$commentcount = $rscomentcount[0];
}
//#####################################
$sqlcommenttotal = "SELECT sum(ratings) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE software_product_id='$rs[software_product_id]'";
$qsqlcmmenttotal = mysqli_query($con,$sqlcommenttotal);
$rscomenttotal = mysqli_fetch_array($qsqlcmmenttotal);
if (is_null($rscomenttotal[0])) {
	$comenttotal = 0;
} else {
	$comenttotal = $rscomenttotal[0];
}
//#####################################
if($comenttotal == 0)
{
	$tot = 0;
}
else
{
	$tot =  round($comenttotal / $commentcount);
}
?>
<span class="fa fa-star
<?php
if($tot >=1)
{
	echo "checked";
}
?>"></span>
<span class="fa fa-star 
<?php
if($tot >=2)
{
	echo "checked";
}
?>"></span>
<span class="fa fa-star 
<?php
if($tot >=3)
{
	echo "checked";
}
?>"></span>
<span class="fa fa-star
<?php
if($tot >=4)
{
	echo "checked";
}
?>"></span>
<span class="fa fa-star
<?php
if($tot >=5)
{
	echo "checked";
}
?>"></span>

		</div>						
		<a href="softappdetail.php?software_product_id=<?php echo $rs[0]; ?>" class="tm-tours-box-2-link">View more</a>
	</div>
</div>
				<?php
				if($col==3)
				{
				?>
				</div>
				<br>
				<?php
				$col=0;
				}
				else
				{
					$col = $col +1;
				}
				?>
				
<?php
	}
?>
				
<?php
/*				
				<div class="row">
					<div class="col-lg-12">
						<p class="home-description">Lorem quis bibendum auctor, nisi elit consequat ipsum, nec sagittis sem nibh id elit. Duis sed odio sit amet nibh vulputate cursus a sit amet mauris.
						Morbi accumsaipsu m velit. Nam nec tellus a odio tincidunt auctor a ornare odio. Sed non mauris vitae erat.
						</p>					
					</div>
				</div>	
*/
?>
				

		</div>
	</section>
	<hr>
<?php
	}
}
?>

<?php
include("footer.php");
?>