<?php 
include("header.php");
if(!isset($_SESSION['adminid']))
{
	echo "<script>window.location='adminloginpanel.php'; </script>";
}
if($_SESSION['randnumber']  == $_POST['randnumber'])
{
	$description = mysqli_real_escape_string($con,$_POST['description']);
	if(isset($_POST['submit']))
	{
		$imgname1 = rand() . $_FILES['imge']['name'];
		move_uploaded_file($_FILES['imge']['tmp_name'],"imgcategory/" . $imgname1);
		if(isset($_GET['editid']))
		{
			$sql ="UPDATE category SET  `category`='$_POST[category]',  `description`='$description'";
			if($_FILES['imge']['name'] != "")
			{
			$sql = $sql . ", `img`='$imgname1'";
			}
			$sql  = $sql . ", `status`='$_POST[status]' where category_id='$_GET[editid]'";
			if(!mysqli_query($con,$sql))
			{
				echo "Error in mysqli query";
			}
			else
			{
				echo "<script>alert('Category record updated successfully...');</script>";
			}
		}
		else
		{
			$sql="INSERT INTO `category`(`category_id`, `category`, `description`, `img`, `status`) VALUES ('','$_POST[category]','$description','$imgname1','$_POST[status]')";
			if(!mysqli_query($con,$sql))
			{
				echo "Error in mysqli query" . mysqli_error($con);
			}
			else
			{
				echo "<script>alert(' Category record inserted successfully...');</script>";
			}	
		}
	}
}
$randnumber = rand();
$_SESSION['randnumber'] = $randnumber;
if(isset($_GET['editid']))
{
	$sql = "SELECT * FROM category WHERE category_id='$_GET[editid]'";
	$qsql = mysqli_query($con,$sql);
	$rsedit = mysqli_fetch_array($qsql);
}
?>
  <main id="main">



    <!-- ======= Contact Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="row">
		

          <div class="col-lg-12" data-aos="fade-up" data-aos-delay="100">
            <div class="info mt-4 ">
			
		<center><h2>Add or Edit Software Category</h2></center><hr>

<form method="post" action="" enctype="multipart/form-data" name="frmcategory" onSubmit="return validatecategory()">
<input type="hidden" name="randnumber" value="<?php echo $randnumber; ?>" >
				  
<div class="form-row">
	<div class="col-md-12 form-group">
	Category <font color="#FF0000">*</font>
	  <input type="text" name="category" id="category" value="<?php echo $rsedit['category']; ?>" class="form-control">
	</div>	
	
	<div class="col-md-12 form-group">
	Image <font color="#FF0000">*</font>
	  <input type="file" name="imge" id="imge" class="form-control">
<?php
if(isset($_GET['editid']))
{
	echo "<a href='imgcategory/$rsedit[img]' download class='btn btn-info'>Download</a>";
}
?>	  
	</div>	
	
	<div class="col-md-12 form-group">
	Description <font color="#FF0000">*</font>
	  <textarea  name="description" id="description" class="form-control" ><?php echo $rsedit['description']; ?></textarea>
	</div>	
	
	<div class="col-md-12 form-group">
	Status <font color="#FF0000">*</font>
	  <select name="status" id="status" class="form-control">
			<option value="">Select Status</option>
		  <?php
		  $arr= array("Active","Inactive");
		  foreach($arr as $val)
		  {
			  if($rsedit['status'] == $val)
			  {
			  echo "<option value='$val' selected >$val</option>";
			  }
			  else
			  {
			  echo "<option value='$val'>$val</option>";
			  }
		  }
		  ?>
	  </select>
	</div>	
	
</div>

<hr>
<centeR><button type="submit" name="submit" id="submit" class="btn btn-info" >Submit</button></center>

</form>
            </div>
				
			</div>		
		</div>
	</section>	


  </main><!-- End #main -->
  <br>
<?php
include("footer.php");
?>
<?php
if(isset($_GET['editid']))
{
	
?>
	<script type="application/javascript">
	
    function validatecategory()
    {
		
var alphaspaceExp = /^[a-zA-Z\s]+$/; //Variable to validate only alphabets and space


	if(document.frmcategory.category.value == "")
	{
		alert("Category should not be empty..");
		document.frmcategory.category.focus();
		return false;
	}
	else if(!document.frmcategory.category.value.match(alphaspaceExp))
	{
		alert("Please enter only letters for Category..");
		document.frmcategory.category.focus();
		return false;
	}
	else
	{
		return true;
	}
	}
    </script>
<?php
}
else
{
?>
	<script type="application/javascript">
	
    function validatecategory()
    {
		
var alphaspaceExp = /^[a-zA-Z\s]+$/; //Variable to validate only alphabets and space


	if(document.frmcategory.category.value == "")
	{
		alert("Category should not be empty..");
		document.frmcategory.category.focus();
		return false;
	}
	else if(!document.frmcategory.category.value.match(alphaspaceExp))
	{
		alert("Please enter only letters for Category..");
		document.frmcategory.category.focus();
		return false;
	}
	else if(document.frmcategory.imge.value == "")
	{
		alert("Kindly select an image..");
		document.frmcategory.imge.focus();
		return false;
	}
	else
	{
		return true;
	}
	}
    </script>
<?php
}
?>