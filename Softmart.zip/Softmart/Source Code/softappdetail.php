<?php
include("header.php");
$sql = "SELECT * FROM software_product WHERE status='Active' AND software_product_id='$_GET[software_product_id]'";
$qsql = mysqli_query($con,$sql);
$rs = mysqli_fetch_array($qsql);
$sqlcategory = "SELECT * FROM category WHERE category_id='$rs[category_id]'";
$qsqlcategory = mysqli_query($con,$sqlcategory);
$rseditcategory = mysqli_fetch_array($qsqlcategory);
$ia=0;
if(isset($_POST['btncomment']))
{
	$dttim = date("Y-m-d H:i:s");
	$sqldelete = "DELETE FROM comment WHERE customer_id='$_SESSION[customerid]' AND software_product_id='$_GET[software_product_id]'";
	$qsqldelete = mysqli_query($con,$sqldelete);
	$commentnote= mysqli_real_escape_string($con,$_POST['comment_note']);
	$sqlcomment = "INSERT INTO comment( `customer_id`, `software_product_id`, `comment_date`, `ratings`, `comment_note`) values('$_SESSION[customerid]','$_GET[software_product_id]','$dttim','$_POST[mystar]','$commentnote')";
	$qsql = mysqli_query($con,$sqlcomment);
	echo "<script>alert('Comment published successfully..');</script>";
	echo "<script>window.location='softappdetail.php?software_product_id=$_GET[software_product_id]';</script>";
}
?>
<style>
.btn-grey{
    background-color:#D8D8D8;
	color:#FFF;
}
.rating-block{
	background-color:#FAFAFA;
	border:1px solid #EFEFEF;
	padding:15px 15px 20px 15px;
	border-radius:3px;
}
.bold{
	font-weight:700;
}
.padding-bottom-7{
	padding-bottom:7px;
}

.review-block{
	background-color:#FAFAFA;
	border:1px solid #EFEFEF;
	padding:15px;
	border-radius:3px;
	margin-bottom:15px;
}
.review-block-name{
	font-size:12px;
	margin:10px 0;
}
.review-block-date{
	font-size:12px;
}
.review-block-rate{
	font-size:13px;
	margin-bottom:15px;
}
.review-block-title{
	font-size:15px;
	font-weight:700;
	margin-bottom:10px;
}
.review-block-description{
	font-size:13px;
}
</style>
	
	<!-- Banner -->
	<section class="tm-banner">
		<!-- Flexslider -->
		<div class="flexslider flexslider-banner">
		  <ul class="slides">
<?php
if(file_exists("imgsoftwareproduct/".$rs['product_img2']))
{
?>	
		    <li>
			    <div class="tm-banner-inner">
					<h1 class="tm-banner-title" style="background: #181717;opacity: .5;"><span class="tm-yellow-text"><?php echo $rs['product_name']; ?></span></h1>
					<?php /*<p class="tm-banner-subtitle">For Your Vacations</p>
					<a href="#more" class="tm-banner-link">Learn More</a>	*/ ?>
				</div>
		      <img src="imgsoftwareproduct/<?php echo $rs['product_img2']; ?>" style="height: 467px;" />
		    </li>
<?php
$ia =1;
}
?>		
<?php
if(file_exists("imgsoftwareproduct/".$rs['product_img3']))
{
?>	
		    <li>
			    <div class="tm-banner-inner">
					<h1 class="tm-banner-title" style="background: #181717;opacity: .5;"><span class="tm-yellow-text"><?php echo $rs['product_name']; ?></span></h1>
					<?php /*<p class="tm-banner-subtitle">For Your Vacations</p>
					<a href="#more" class="tm-banner-link">Learn More</a>	*/ ?>
				</div>
		      <img src="imgsoftwareproduct/<?php echo $rs['product_img3']; ?>" style="height: 467px;" />
		    </li>
<?php
$ia =1;
}
?>		
<?php
if(file_exists("imgsoftwareproduct/".$rs['product_img4']))
{
?>	
		    <li>
			    <div class="tm-banner-inner">
					<h1 class="tm-banner-title" style="background: #181717;opacity: .5;"><span class="tm-yellow-text"><?php echo $rs['product_name']; ?></span></h1>
					<?php /*<p class="tm-banner-subtitle">For Your Vacations</p>
					<a href="#more" class="tm-banner-link">Learn More</a>	*/ ?>
				</div>
		      <img src="imgsoftwareproduct/<?php echo $rs['product_img4']; ?>" style="height: 467px;" />
		    </li>
<?php
$ia =1;
}
?>		
<?php
if(file_exists("imgsoftwareproduct/".$rs['product_img5']))
{
?>	
		    <li>
			    <div class="tm-banner-inner">
					<h1 class="tm-banner-title" style="background: #181717;opacity: .5;"><span class="tm-yellow-text"><?php echo $rs['product_name']; ?></span></h1>
					<?php /*<p class="tm-banner-subtitle">For Your Vacations</p>
					<a href="#more" class="tm-banner-link">Learn More</a>	*/ ?>
				</div>
		      <img src="imgsoftwareproduct/<?php echo $rs['product_img5']; ?>" style="height: 467px;" />
		    </li>
<?php
$ia =1;
}
?>		
<?php
if(file_exists("imgsoftwareproduct/".$rs['product_img2']))
{
?>	
		    <li>
			    <div class="tm-banner-inner">
					<h1 class="tm-banner-title" ><span class="tm-yellow-text" style=""><?php echo $rs['product_name']; ?></span></h1>
					<?php /*<p class="tm-banner-subtitle">For Your Vacations</p>
					<a href="#more" class="tm-banner-link">Learn More</a>	*/ ?>
				</div>
		      <img src="imgsoftwareproduct/<?php echo $rs['product_img2']; ?>" style="height: 467px;" />
		    </li>
<?php
$ia =1;
}
if($ia == 0)
{
?>	
		    <li>
			    <div class="tm-banner-inner">
					<h1 class="tm-banner-title"><span class="tm-yellow-text"><?php echo $rs['product_name']; ?></span></h1>
					<?php /*<p class="tm-banner-subtitle">For Your Vacations</p>
					<a href="#more" class="tm-banner-link">Learn More</a>	*/ ?>
				</div>
		      <img src="img/slider.jpg" style="height: 250px;" />
		    </li>
<?php
}
?>
		  </ul>
		</div>		
	</section>


	<!-- gray bg -->	
	<section class="container tm-home-section-1" id="more">
		<div class="row">
			<!-- slider -->
			<div class="flexslider flexslider-about effect2">
			  <ul class="slides">
			    <li>
				<img src="imgsoftwareproduct/<?php echo $rs['product_img1']; ?>" alt="<?php echo $rs['product_name']; ?>" />
			      <div class="flex-caption">
			      	<h2 class="slider-title"><?php echo $rs['product_name']; ?></h2>
			      	<h3 class="slider-subtitle" style='color: grey;'>Software Type: <?php echo $rs['software_type']; ?></h3>
			      	<p class="slider-description"><?php echo $rs['product_description']; ?></p>
			      	<h3 class="slider-subtitle">Software Category: <?php echo $rseditcategory['category']; ?></h3>
					<p class="slider-description">
						<hr>
						<?php
						if(isset($_SESSION['customerid']))
						{
						?>
						<b>Download <?php echo $rs['software_type']; ?></b><br>
						<a href="downloadlink/<?php echo $rs['download_link']; ?>"  class="btn btn-info btn-lg" onclick="storedownload('<?php echo $_GET['software_product_id']; ?>')" ><i class="fa fa-download" aria-hidden="true"></i> Download Link</a>
						<?php
						}
						else
						{
						?>
						<b>Login to Download<br>
						<a href="customerloginpanel.php?software_product_id=<?php echo $_GET['software_product_id']; ?>" class="btn btn-primary" >Click here to Login</a>
						<?php
						}
						?>
					</p>
					
			      	<div class="slider-social">
			      		<a href="#" class="tm-social-icon"><i class="fa fa-twitter"></i></a>
			      		<a href="#" class="tm-social-icon"><i class="fa fa-facebook"></i></a>
			      		<a href="#" class="tm-social-icon"><i class="fa fa-pinterest"></i></a>
			      		<a href="#" class="tm-social-icon"><i class="fa fa-google-plus"></i></a>
			      	</div>
			      </div>			      
			    </li>
			  </ul>
			</div>
		</div>
	</section>	

	
	<!-- white bg -->
	<section class="tm-white-bg section-padding-bottom">
		<div class="container">

			<div class="row">
				<div class="tm-section-header section-margin-top" style="margin-bottom: 25px;margin-top: 25px;">
					<div class="col-lg-4 col-md-3 col-sm-3"><hr></div>
					<div class="col-lg-4 col-md-6 col-sm-6"><h2 class="tm-section-title">FEEDBACK & REVIEWS</h2></div>
					<div class="col-lg-4 col-md-3 col-sm-3"><hr></div>	
				</div>				
			</div>
			
			<div class="row">
					<div class="col-md-12">
<?php
if(isset($_SESSION['customerid']))
{
?>
	<center><input type="button" class="btn btn-success btn-lg" value="Click here to Post FEEDBACK"  data-toggle="modal" data-target="#myModal"></center>
<?php
}
else
{
?>
	<center><a href="customerloginpanel.php?software_product_id=<?php echo $_GET['software_product_id']; ?>" class="btn btn-primary" >Login to Post FEEDBACK</a></center>
<?php
}
?>
					<hr>
					</div>				
			</div>
			
			<div class="row">
			
				<!-- Testimonial -->
				<div>
				
			

    <div class="container">
    			
		<div class="row">
			<div class="col-sm-6">
				<div class="rating-block">
					<h4>Average user rating</h4>
					<h1 class="bold padding-bottom-7">


					<small> 
<?php
//#####################################
$sqlcommentcount = "SELECT count(*) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE software_product_id='$_GET[software_product_id]'";
$qsqlcmmentcount = mysqli_query($con,$sqlcommentcount);
$rscomentcount = mysqli_fetch_array($qsqlcmmentcount);
if (is_null($rscomentcount[0])) {
	$commentcount = 0;
} else {
	$commentcount = $rscomentcount[0];
}
//#####################################
$sqlcommenttotal = "SELECT sum(ratings) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE software_product_id='$_GET[software_product_id]'";
$qsqlcmmenttotal = mysqli_query($con,$sqlcommenttotal);
$rscomenttotal = mysqli_fetch_array($qsqlcmmenttotal);
if (is_null($rscomenttotal[0])) {
	$comenttotal = 0;
} else {
	$comenttotal = $rscomenttotal[0];
}
//#####################################
if($comenttotal == 0)
{
	echo 0;
	$tot = 0;
}
else
{
	echo  number_format($comenttotal / $commentcount,1);
	$tot =  round($comenttotal / $commentcount);
}
?>
					/ 5</small></h1>


								<button type="button" class="<?php
	  if($tot >= 1 )
	  {
		  echo  " btn btn-warning btn-sm ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-sm ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
								<button type="button" class="<?php
	  if($tot >= 2 )
	  {
		  echo  " btn btn-warning btn-sm ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-sm ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
								<button type="button" class="<?php
	  if($tot >= 3 )
	  {
		  echo  " btn btn-warning btn-sm ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-sm ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
								<button type="button" class="<?php
	  if($tot >= 4 )
	  {
		  echo  " btn btn-warning btn-sm ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-sm ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
								<button type="button" class="<?php
	  if($tot >= 5 )
	  {
		  echo  " btn btn-warning btn-sm ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-sm ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
<br>
<b>Total <?php echo $rscomentcount[0]; ?> Comments...</b>

				</div>
			</div>
			<div class="col-sm-3">
				<h4>Rating breakdown</h4>
				<div class="pull-left">
					<div class="pull-left" style="width:35px; line-height:1;">
						<div style="height:9px; margin:5px 0;">5 <span class="glyphicon glyphicon-star"></span></div>
					</div>
					<div class="pull-left" style="width:180px;">
						<div class="progress" style="height:9px; margin:8px 0;">
						  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="5" aria-valuemin="0" aria-valuemax="5" style="width: 1000%">
							<span class="sr-only">80% Complete (danger)</span>
						  </div>
						</div>
					</div>
					<div class="pull-right" style="margin-left:10px;">
<?php
$sqlcommentcount = "SELECT count(*) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE software_product_id='$_GET[software_product_id]' AND comment.ratings='5'";
$qsqlcmmentcount = mysqli_query($con,$sqlcommentcount);
$rscomentcount = mysqli_fetch_array($qsqlcmmentcount);
echo $rscomentcount[0];
?>
					</div>
				</div>
				<div class="pull-left">
					<div class="pull-left" style="width:35px; line-height:1;">
						<div style="height:9px; margin:5px 0;">4 <span class="glyphicon glyphicon-star"></span></div>
					</div>
					<div class="pull-left" style="width:180px;">
						<div class="progress" style="height:9px; margin:8px 0;">
						  <div class="progress-bar progress-bar-primary" role="progressbar" aria-valuenow="4" aria-valuemin="0" aria-valuemax="5" style="width: 80%">
							<span class="sr-only">80% Complete (danger)</span>
						  </div>
						</div>
					</div>
					<div class="pull-right" style="margin-left:10px;">
<?php
$sqlcommentcount = "SELECT count(*) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE software_product_id='$_GET[software_product_id]' AND comment.ratings='4'";
$qsqlcmmentcount = mysqli_query($con,$sqlcommentcount);
$rscomentcount = mysqli_fetch_array($qsqlcmmentcount);
echo $rscomentcount[0];
?>
					</div>
				</div>
				<div class="pull-left">
					<div class="pull-left" style="width:35px; line-height:1;">
						<div style="height:9px; margin:5px 0;">3 <span class="glyphicon glyphicon-star"></span></div>
					</div>
					<div class="pull-left" style="width:180px;">
						<div class="progress" style="height:9px; margin:8px 0;">
						  <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="3" aria-valuemin="0" aria-valuemax="5" style="width: 60%">
							<span class="sr-only">80% Complete (danger)</span>
						  </div>
						</div>
					</div>
					<div class="pull-right" style="margin-left:10px;">
<?php
$sqlcommentcount = "SELECT count(*) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE software_product_id='$_GET[software_product_id]' AND comment.ratings='3'";
$qsqlcmmentcount = mysqli_query($con,$sqlcommentcount);
$rscomentcount = mysqli_fetch_array($qsqlcmmentcount);
echo $rscomentcount[0];
?>
					</div>
				</div>
				<div class="pull-left">
					<div class="pull-left" style="width:35px; line-height:1;">
						<div style="height:9px; margin:5px 0;">2 <span class="glyphicon glyphicon-star"></span></div>
					</div>
					<div class="pull-left" style="width:180px;">
						<div class="progress" style="height:9px; margin:8px 0;">
						  <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="2" aria-valuemin="0" aria-valuemax="5" style="width: 40%">
							<span class="sr-only">80% Complete (danger)</span>
						  </div>
						</div>
					</div>
					<div class="pull-right" style="margin-left:10px;">
<?php
$sqlcommentcount = "SELECT count(*) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE software_product_id='$_GET[software_product_id]' AND comment.ratings='2'";
$qsqlcmmentcount = mysqli_query($con,$sqlcommentcount);
$rscomentcount = mysqli_fetch_array($qsqlcmmentcount);
echo $rscomentcount[0];
?>
					</div>
				</div>
				<div class="pull-left">
					<div class="pull-left" style="width:35px; line-height:1;">
						<div style="height:9px; margin:5px 0;">1 <span class="glyphicon glyphicon-star"></span></div>
					</div>
					<div class="pull-left" style="width:180px;">
						<div class="progress" style="height:9px; margin:8px 0;">
						  <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="1" aria-valuemin="0" aria-valuemax="5" style="width: 20%">
							<span class="sr-only">80% Complete (danger)</span>
						  </div>
						</div>
					</div>
					<div class="pull-right" style="margin-left:10px;">
<?php
$sqlcommentcount = "SELECT count(*) FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE software_product_id='$_GET[software_product_id]' AND comment.ratings='1'";
$qsqlcmmentcount = mysqli_query($con,$sqlcommentcount);
$rscomentcount = mysqli_fetch_array($qsqlcmmentcount);
echo $rscomentcount[0];
?>
					</div>
				</div>
				</div>
			</div>			
		</div>			
		
		<div class="row">
			<div class="col-sm-12">
				<hr/>
				<div class="review-block">
				
<?php
$sqlcomment1 = "SELECT * FROM comment LEFT JOIN customer ON comment.customer_id=customer.customer_id WHERE software_product_id='$_GET[software_product_id]' ORDER BY comment.comment_date DESC";
$qsqlcmment = mysqli_query($con,$sqlcomment1);
while($rscoment = mysqli_fetch_array($qsqlcmment))
{
	if(file_exists("imgcustomer/".$rscoment['profile_img']))
	{
		$img = "imgcustomer/".$rscoment['profile_img'];
	}
	else
	{
		$img = "images/noimage.png";
	}
?>				
					<div class="row">
						<div class="col-sm-3">
							<img src="<?php echo $img; ?>" class="img-rounded" style="width: 120px;height: 125px;" align="left" >
							<div class="review-block-name"><b style='color: blue;margin-left: 10px;'><?php echo $rscoment['customer_name']; ?></b></div>
							<div class="review-block-date"><b style='margin-left: 10px;'><?php echo date("F d, Y",strtotime($rscoment['comment_date'])); ?></b><br/><?php /* <b style='margin-left: 10px;'>1 day ago</b>*/ ?></div>
						</div>
						<div class="col-sm-9">
							<div class="review-block-rate">
								<button type="button" class="<?php
	  if($rscoment['ratings'] >= 1 )
	  {
		  echo  " btn btn-warning btn-xs ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-xs ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
								<button type="button" class="<?php
	  if($rscoment['ratings'] >= 2 )
	  {
		  echo  " btn btn-warning btn-xs ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-xs ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
								<button type="button" class="<?php
	  if($rscoment['ratings'] >= 3 )
	  {
		  echo  " btn btn-warning btn-xs ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-xs ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
								<button type="button" class="<?php
	  if($rscoment['ratings'] >= 4 )
	  {
		  echo  " btn btn-warning btn-xs ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-xs ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
								<button type="button" class="<?php
	  if($rscoment['ratings'] >= 5 )
	  {
		  echo  " btn btn-warning btn-xs ";
	  }
	  else
	  {
		  echo  " btn btn-default btn-grey btn-xs ";
	  }
	  ?>" aria-label="Left Align">
								  <span class="glyphicon glyphicon-star" aria-hidden="true"></span>
								</button>
							</div>
							<?php /*<div class="review-block-title">this was nice in buy</div>*/ ?>
							<div class="review-block-description"><?php echo $rscoment['comment_note']; ?></div>
						</div>
					</div>
					<hr/>
<?php
}
?>
				
				</div>
			</div>
		</div>
		
    </div> <!-- /container -->


			
			
				</div>							
			
			</div>			
		</div>
	</section>
<?php
include("footer.php");
?>
<?php
$sqlcomment = "SELECT * FROM comment WHERE customer_id='$_SESSION[customerid]' AND software_product_id='$_GET[software_product_id]'";
$qsqlcomment = mysqli_query($con,$sqlcomment);
$rscomment = mysqli_fetch_array($qsqlcomment);
?>
<form method="post" action="">
	<div id="myModal" class="modal fade" role="dialog">
	  <div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
		  <div class="modal-header">
			<button type="button" class="close" data-dismiss="modal">&times;</button>
			<h4 class="modal-title">Post FeedBack and Reviews Here...</h4>
		  </div>
		  <div class="modal-body">
			<p>
	<textarea class="form-control" name="comment_note" id="comment_note" rows="5" placeholder="Enter your valueable feedback.."><?php echo $rscomment['comment_note']; ?></textarea>
	<br>
			</p>
			<p>
<style type="text/css">

      #w3hubs
      {
		position: absolute;
		transform: rotateY(180deg);
		display: flex;
      }
      #w3hubs input{
      display: none;
      }
      #w3hubs label
      {
      display: block;
      cursor: pointer;
      width: 100px;
      }
      #w3hubs label:before
      {
      content: '\f005';
      font-family:  fontAwesome;
      position: relative;
      display: block;
      font-size: 100px;
      color: #101010;
      }
      #w3hubs label:after
      {
      content: '\f005';
      font-family:  fontAwesome;
      position: absolute;
      display: block;
      font-size: 100px;
      background: linear-gradient(#ff8a00 0%, #da1b60 100%);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      top: 0;
      opacity: 0;
      }
      #w3hubs label:hover{
      -webkit-transform: rotate(120deg);
      transform: rotate(120deg);
      transition: .5s;
      }
      #w3hubs label:before{
      text-shadow: 0 0 10px #2E86C1;
      }
      #w3hubs label:hover:after,
      #w3hubs label:hover ~ label:after,
      #w3hubs input:checked ~ label:after
      {
      opacity: 1;
      }
      @media(max-width: 502px)
      {
      #w3hubs label{
      width: 80px;
      }
      #w3hubs label:before
      { 
      font-size: 80px;  
      }
      #w3hubs label:after
      { 
      font-size: 80px;
      }
      }
      @media(max-width: 407px)
      {
      #w3hubs label{
      width: 50px;
      }
      #w3hubs label:before
      { 
      font-size: 50px;  
      }
      #w3hubs label:after
      { 
      font-size: 50px;
      }
      }
    </style>
<b>Add Ratings :</b>
    <div id="w3hubs">
      <input type="radio" name="star" id="star1" onclick="selectstar(5)" 
	  <?php
	  if($rscomment['ratings'] == 5 )
	  {
		  echo  " checked ";
	  }
	  ?>
	  ><label for="star1"></label>
      <input type="radio" name="star" id="star2" onclick="selectstar(4)" 
	  <?php
	  if($rscomment['ratings'] == 4 )
	  {
		  echo  " checked ";
	  }
	  ?>
	  ><label for="star2"></label>
      <input type="radio" name="star" id="star3" onclick="selectstar(3)"  
	  <?php
	  if($rscomment['ratings'] == 3 )
	  {
		  echo  " checked ";
	  }
	  ?>
	  ><label for="star3"></label>
      <input type="radio" name="star" id="star4" onclick="selectstar(2)" 
	  <?php
	  if($rscomment['ratings'] == 2 )
	  {
		  echo  " checked ";
	  }
	  ?>
	  ><label for="star4"></label>
      <input type="radio" name="star" id="star5" onclick="selectstar(1)" 
	  <?php
	  if($rscomment['ratings'] == 1 )
	  {
		  echo  " checked ";
	  }
	  ?>
	  ><label for="star5"></label>
    </div>	
	<input type="hidden" name="mystar" id="mystar"  >
<br>	
<br>	
<br>	
<br>	
<br>	
<br>	
			</p>
		  </div>
		  <div class="modal-footer">
			<button type="submit" name="btncomment" id="btncomment" class="btn btn-info btn-lg" >Post Feed Back</button>
		  </div>
		</div>
	  </div>
	</div>
</form>
<script>
function storedownload(software_product_id)
{
	var xmlhttp = new XMLHttpRequest();
	   xmlhttp.onreadystatechange = function() {
      if (this.readyState == 4 && this.status == 200) {        
		//alert("Download Started..");
      }
    };
    xmlhttp.open("GET","ajaxstoredownload.php?software_product_id="+software_product_id,true);
    xmlhttp.send();
}
function selectstar(starrating)
{
		//alert(starrating);
		document.getElementById("mystar").value=starrating;
}
</script>
<script type="text/javascript" src="js/bootstrap-datetimepicker.min.js"></script>	<!-- bootstrap date time picker js, http://eonasdan.github.io/bootstrap-datetimepicker/ -->
	<script type="text/javascript" src="js/jquery.flexslider-min.js"></script>
<!--
	<script src="js/froogaloop.js"></script>
	<script src="js/jquery.fitvid.js"></script>
-->
   	<script type="text/javascript" src="js/templatemo-script.js"></script>      		<!-- Templatemo Script -->
	<script>
		// HTML document is loaded. DOM is ready.
		$(function() {

			$('#hotelCarTabs a').click(function (e) {
			  e.preventDefault()
			  $(this).tab('show')
			})

        	$('.date').datetimepicker({
            	format: 'MM/DD/YYYY'
            });
            $('.date-time').datetimepicker();

			// https://css-tricks.com/snippets/jquery/smooth-scrolling/
		  	$('a[href*=#]:not([href=#])').click(function() {
			    if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
			      var target = $(this.hash);
			      target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
			      if (target.length) {
			        $('html,body').animate({
			          scrollTop: target.offset().top
			        }, 1000);
			        return false;
			      }
			    }
		  	});
		});
		
		// Load Flexslider when everything is loaded.
		$(window).load(function() {	  		
			// Vimeo API nonsense

/*
			  var player = document.getElementById('player_1');
			  $f(player).addEvent('ready', ready);
			 
			  function addEvent(element, eventName, callback) {
			    if (element.addEventListener) {
			      element.addEventListener(eventName, callback, false)
			    } else {
			      element.attachEvent(eventName, callback, false);
			    }
			  }
			 
			  function ready(player_id) {
			    var froogaloop = $f(player_id);
			    froogaloop.addEvent('play', function(data) {
			      $('.flexslider').flexslider("pause");
			    });
			    froogaloop.addEvent('pause', function(data) {
			      $('.flexslider').flexslider("play");
			    });
			  }
*/

			 
			 
			  // Call fitVid before FlexSlider initializes, so the proper initial height can be retrieved.
/*

			  $(".flexslider")
			    .fitVids()
			    .flexslider({
			      animation: "slide",
			      useCSS: false,
			      animationLoop: false,
			      smoothHeight: true,
			      controlNav: false,
			      before: function(slider){
			        $f(player).api('pause');
			      }
			  });
*/


			  

//	For images only
		    $('.flexslider').flexslider({
			    controlNav: false
		    });


	  	});
	</script>
	
	  