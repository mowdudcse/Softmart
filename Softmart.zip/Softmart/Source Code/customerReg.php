<?php 
include("header.php");
include("dbconnection.php");
if(isset($_SESSION['customerid']))
{
	echo "<script>window.location='customerpanel.php';</script>";
}
if($_SESSION['randnumber']  == $_POST['randnumber'])
{
	if(isset($_POST['submit']))
	{
		$profile_img = rand() . $_FILES['profile_img']['name'];
		move_uploaded_file($_FILES['profile_img']['tmp_name'],"imgcustomer/".$profile_img);
		
			$sql="INSERT INTO `customer`( `customer_name`, `address`, `mobile_no`, `email_id`, `password`, `profile_img`, `status`) VALUES ('$_POST[customername]','$_POST[address]','$_POST[mblnum]','$_POST[email_id]','$_POST[password]','$profile_img','$_POST[status]')";	
			if(!mysqli_query($con,$sql))
			{
				echo "Error in mysqli query ".mysqli_error($con);
			}
			else
			{
						echo "<script>alert('Customer Registred successfully...');</script>";
						echo "<script>window.location='customerloginpanel.php';</script>";				
			}
	}
}
$randnumber = rand();
$_SESSION['randnumber'] = $randnumber;
if(isset($_GET['editid']))
{
	$sql = "SELECT * FROM customer WHERE customer_id='$_GET[editid]'";
	$qsql = mysqli_query($con,$sql);
	$rsedit = mysqli_fetch_array($qsql);
}
?>

  <main id="main">
  
      <!-- ======= Breadcrumbs ======= -->
    <section id="breadcrumbs" class="breadcrumbs">
      <div class="container">
<br>
        <div class="d-flex justify-content-between align-items-center">
          <center><h2>Customer Registration Panel</h2></center>

        </div>

      </div>
    </section><!-- End Breadcrumbs -->
<hr>

    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container">
        <div class="row">
          <div class="col-lg-12">
            <div class="row">
			
              <div class="col-md-3 d-flex align-items-stretch mt-4 mt-lg-0">
                <div class="icon-box" data-aos="zoom-in" data-aos-delay="200" style="width: 100%;">
                  <h4>Register as Customer</h4>
                  <img src="images/customericon.jpg" style="width: 100%;">
                </div>
              </div>
              <div class="col-md-9 d-flex align-items-stretch">
                <div class="icon-box" data-aos="zoom-in" data-aos-delay="100" style="width: 100%;text-align: left;">
<form method="post" action="" name="frmcstreg" onSubmit="return validatecstreg()" enctype="multipart/form-data">
<input type="hidden" name="randnumber" value="<?php echo $randnumber; ?>" >
                  <h4>Registration Panel</h4>
				  
<div class="form-row">
	<div class="col-md-6 form-group">
	Customer Name <font color="#FF0000">*</font>
	  <input type="text" name="customername" id="customername" class="form-control" >
	</div>	
	
	<div class="col-md-6 form-group">
	Email ID <font color="#FF0000">*</font>
	  <input type="email" name="email_id" id="email_id" value="<?php echo $rsedit['email_id']; ?>" class="form-control" >
	</div>	
	
	<div class="col-md-6 form-group">
	Password <font color="#FF0000">*</font>
	  <input type="password" name="password" id="password" value="<?php echo $rsedit['password']; ?>" class="form-control" >
	</div>
	
	<div class="col-md-6 form-group">
	Confirm Password <font color="#FF0000">*</font>
	  <input type="password" name="cpassword" id="cpassword" value="<?php echo $rsedit['password']; ?>" class="form-control" >
	</div>	
	
	<div class="col-md-12 form-group">
	 Address <font color="#FF0000">*</font>
	  <textarea name="address" id="address" class="form-control"><?php echo $rsedit['address']; ?></textarea>
	</div>
	
	<div class="col-md-6 form-group">
	Mobile Number <font color="#FF0000"> *</font>
	  <input type="number" name="mblnum" id="mblnum" value="<?php echo $rsedit['mobile_no']; ?>" class="form-control">
	</div>
		
	<div class="col-md-6 form-group">
	Upload Profile Image <font color="#FF0000"> *</font>
	  <input type="file" name="profile_img" id="profile_img"  class="form-control">
	</div>
		

	<input type="hidden" name="status" value="Active" >

	
</div>

<button type="submit" name="submit" id="submit" class="btn btn-info btn-lg btn-block" >Click here to Register</button>

</form>
                </div>
              </div>


            </div>
          </div>
        </div>

      </div>
    </section><!-- End Services Section -->

<hr>
  </main><!-- End #main -->
  
<?php
include("footer.php");
?>
<script type="application/javascript">
function validatecstreg()
{

var alphaExp = /^[a-zA-Z]+$/; //Variable to validate only alphabets
var alphaspaceExp = /^[a-zA-Z\s]+$/; //Variable to validate only alphabets and space
var numericExpression = /^[0-9]+$/; //Variable to validate only numbers
var emailExp = /^[\w\-\.\+]+\@[a-zA-Z0-9\.\-]+\.[a-zA-z0-9]{2,4}$/; //Variable to validate Email ID

	if(document.frmcstreg.customername.value == "")
	{
		alert("Customer name should not be empty..");
		document.frmcstreg.customername.focus();
		return false;
	}
	else if(!document.frmcstreg.customername.value.match(alphaspaceExp))
	{
		alert("Please enter only letters for Customer name..");
		document.frmcstreg.customername.focus();
		return false;
	}
	else if(document.frmcstreg.email_id.value == "")
	{
		alert("Kindly enter Email ID..");
		document.frmcstreg.email_id.focus();
		return false;
	}		
	else if(!document.frmcstreg.email_id.value.match(emailExp))
	{
		alert("Kindly enter Valid Email ID.");
		document.frmcstreg.email_id.focus();
		return false;
	}
	else if(document.frmcstreg.password.value == "")
	{
		alert("Password should not be empty..");
		document.frmcstreg.password.focus();
		return false;
	}			
	else if(document.frmcstreg.password.value.length < 8)
	{
		alert("Password length should be more than 8 characters...");
		document.frmcstreg.password.focus();
		return false;
	}
	else if(document.frmcstreg.password.value.length > 16)
	{
		alert("Password length should be less than 16 characters...");
		document.frmcstreg.password.focus();
		return false;
	}		
	else if(document.frmcstreg.cpassword.value == "")
	{
		alert("Confirm password should not be empty..");
		document.frmcstreg.cpassword.focus();
		return false;
	}
	else if(document.frmcstreg.password.value != document.frmcstreg.cpassword.value)
	{
		alert("Password and confirm password not matching...");
		document.frmcstreg.cpassword.focus();
		return false;
	}	
	else if(document.frmcstreg.address.value == "")
	{
		alert("Address should not be empty..");
		document.frmcstreg.address.focus();
		return false;
	}
	else if(document.frmcstreg.mblnum.value == "")
	{
		alert("Kindly enter Mobile number..");
		document.frmcstreg.mblnum.focus();
		return false;
	}		
	else if(document.frmcstreg.profile_img.value == "")
	{
		alert("Profile Image should not be empty..");
		document.frmcstreg.profile_img.focus();
		return false;
	}
	else
	{
		return true;
	}
}

</script>